CREATE TABLE `can_data` (
	`entry` int(10) NOT NULL AUTO_INCREMENT PRIMARY KEY,
	`timestamp` varchar(50) NOT NULL,
	`canID` int NOT NULL,
	`msg` int NOT NULL
);
